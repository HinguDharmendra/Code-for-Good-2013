Main directory for the entire application
TFI: android app
Server: server files
