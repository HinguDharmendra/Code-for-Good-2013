package Highcharts-3.0.2.exporting-server.java.highcharts-export.src.main.java.com.highcharts.export.server;


public enum ServerState {
	IDLE, DEAD, BUSY, TIMEDOUT, ACTIVE;
}